## ---- eval = FALSE-------------------------------------------------------
#  install.packages("SentimentIt")
#  
#  #or if the package is already installed
#  library("SentimentIt")

## ---- eval = FALSE-------------------------------------------------------
#  #data
#  load("/Users/johndoe/Desktop/reviews.rda") #data is stored in R workspace as "reviews"
#  
#  #assign an object name to the function so the data with IDs will be stored in your R workspace
#  #in addition to being exported to your desired filepath. In this case, I have assigned the
#  #output the name "reviews_with_ids"
#  reviews_with_ids <- readText(email = "johndoe@school.edu", password = "12345",
#           read_documents_from = reviews,
#           write_documents_to = "/Users/johndoe/Desktop/reviews_with_ids.csv",
#           index = "Review") #"Review" is the column name for the data I want to use in the comparison

## ---- eval = FALSE-------------------------------------------------------
#  
#  batch_ids <- createBatches(email = "johndoe@school.edu", password = "12345",
#                task_setting_id = 28, num_batches = 3)

## ---- eval = FALSE-------------------------------------------------------
#  
#  makeComps(email = "johndoe@school.edu", password = "12345",
#               ids = reviews_ids[,3], number_per = 10,
#               batch_id = batch_ids,
#               question = "Below are two movie reviews. Identify which review you think is more positive.",
#               pairwise_path = "comparisons.Rdata")

## ---- eval = FALSE-------------------------------------------------------
#  
#  createTasks(email = "johndoe@school.edu", password = "12345",
#              batch_id = batch_ids[1]) #the batch_id object contains three unique batch IDs, but we are
#                                       #only sending the first one to Mechanical Turk

## ---- eval = FALSE-------------------------------------------------------
#  
#  batchStatus(email = "johndoe@school.edu", password = "12345",
#                batch_id = batch_ids[1])

## ---- eval = FALSE-------------------------------------------------------
#  
#  comp_output <- readInData(email = "johndoe@school.edu", password = "12345",
#                batch_id = batch_ids[1])

## ---- eval = FALSE-------------------------------------------------------
#  
#  repostExpired(email = "johndoe@school.edu", password = "12345",
#                batch_id = batch_ids[1])

## ---- eval = FALSE-------------------------------------------------------
#  
#  #fitting a non-hierarchical Stan model
#  stan_model <- fitStan(data = batch_ids)
#  #you can use either the batch ID numbers or the output from readInData()
#  stan_model2 <- fitStan(data = comp_output)

## ---- eval = FALSE-------------------------------------------------------
#  
#  ban_workers <- checkWorkers(stan_fit = stan_model, data = output)

