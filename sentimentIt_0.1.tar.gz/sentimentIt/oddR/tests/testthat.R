library(testthat)
library(sentimentIt)

test_check("sentimentIt")
