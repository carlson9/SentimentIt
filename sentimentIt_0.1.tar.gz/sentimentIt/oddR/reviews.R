#' Movie Reviews Example Data set
#'
#' An example dataset of Movie reviews with the number of stars given by Mechanical Turk Workers
#'
#' @format A data frame with 500 rows and 2 variables:
#' \describe{
#'   \item{stars}{rating on scale from 1-5 by Mechanical Turk worker}
#'   \item{Review}{The movie review looked over by worker}
#' }
#' @seealso \code{\link{createTasksTimed}}, \code{\link{batchesWrapper}}, \code{\link{checkCert}},
#' \code{\link{checkWorkers}},\code{\link{createBatches}},\code{\link{createCert}},\code{\link{createTasks}}, 
#' \code{\link{createPairwise}}, \code{\link{extractCoef}},\code{\link{fitStan}},\code{\link{fitStanHier}},
#' \code{\link{givetakeCert}},\code{\link{makeCompsSep}},\code{\link{readInData}}, \code{\link{readText}},
#' \code{\link{repostExpired}},\code{\link{revokeCert}}, \code{\link{sentimentIt}}, \code{\link{batchStatus}},
#' \code{\link{extractCoef}}
#' @author David Carlson
#' @rdname reviews
