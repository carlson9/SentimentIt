Final Project Goals:  TO BE DONE BY THE END 

- Finish documentations for all functions and highest level wrapper (sentimentIt). 
- Hide medium level wrappers to users. (DAVID) - add . to all midlevel functions, and 
    change all seealso
- Finish sentimentIt wrapper (PRIORITY ONE) (JOE)
- Change all "HITS" to be "tasks". (DAVID)
- Fix all parameter names to be more specific (path name) (JOE)
- Make sure function parameters and defaults match throughout.  (TOGETHER NOW)
- Fix check workers function. (TAISHI)



#'  pathFrom = readDocumentsFrom
#' pathTo = writeDocumentsTo
