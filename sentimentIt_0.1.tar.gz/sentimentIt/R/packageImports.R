#' @import plyr
#' @import jsonlite
#' @import httr
#' @import RCurl
#' @import rstan
# This document was created to make sure all the necessary packages 
# get loaded into into the namespace. 