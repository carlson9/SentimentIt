#' @export
.createTasksBatch <- function(email, password, batches, certone, certtwo, min_time=9,
                   max_time=22, rate=1/3, threshold=5, check_workers_at=NULL,
                   hierarchy_data=NULL, hierarchy_var=NULL, cut_point=1, cut_proportion=0.9,
                   n.questions=50, plot_hist=FALSE, file_path=NULL,
                   chains=3, iter=2500, seed=1234, n.cores=3){
  out <- vector()
  q <- 1
  for(i in batches){
    .checkTime(min_time, max_time)
    x <- createTasks(email, password, batch_id=i)
    out[i] <- x
    done <- FALSE
    current <- as.numeric(format(Sys.time(), "%M"))
      while(!done){
        Sys.sleep(rate*3600)
        status <- batchStatus(email, password, batches[i])
        done <- (((status$submitted_count - status$completed_count) <= threshold) | (as.numeric(format(Sys.time(), "M%")) - current > 240))
      }
      if(i %in% batches[check_workers_at]) {
        q <- ifelse(length(hist_path)>q, q+1, q)
        hist_pathi <- hist_path[q]
        .givetakeCert(email, password, certone, certtwo, .stanWrapper(email, password, data=batches[1:length(out)],
                                                 hierarchy_data=hierarchy_data, hierarchy_var=hierarchy_var,
                                                 return_fit=FALSE, cut_point=cut_point, cut_proportion=cut_proportion,
                                                 n.questions=n.questions, plot_hist=plot_hist, hist_path=hist_pathi,
                                                 chains=chains, iter=iter, seed=seed, n.cores=n.cores)[[1]])
      }
  }
  return(out)
}

